# Copyright 2010-2026 The pygit2 contributors
#
# This file is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License, version 2,
# as published by the Free Software Foundation.
#
# In addition to the permissions in the GNU General Public License,
# the authors give you unlimited permission to link the compiled
# version of this file into combinations with other programs,
# and to distribute those combinations without any restriction
# coming from the use of this file.  (The General Public License
# restrictions do apply in other respects; for example, they cover
# modification of the file, and distribution when not linked into
# a combined executable.)
#
# This file is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; see the file COPYING.  If not, write to
# the Free Software Foundation, 51 Franklin Street, Fifth Floor,
# Boston, MA 02110-1301, USA.

from collections.abc import Callable, Iterator
from os import PathLike
from typing import TYPE_CHECKING, Optional

try:
    from functools import cached_property
except ImportError:
    from cached_property import cached_property  # type: ignore

# Import from pygit2
from .errors import check_error
from .ffi import C, ffi
from .utils import encode_fs_path, encode_string

if TYPE_CHECKING:
    from ._libgit2.ffi import GitConfigC, GitConfigEntryC
    from .repository import BaseRepository


def str_to_bytes(value: str | bytes, name: str) -> bytes:
    if not isinstance(value, str):
        raise TypeError(f'{name} must be a string')

    return encode_string(value)


class ConfigIterator:
    def __init__(self, config, ptr) -> None:
        self._iter = ptr
        self._config = config

    def __del__(self) -> None:
        C.git_config_iterator_free(self._iter)

    def __iter__(self) -> 'ConfigIterator':
        return self

    def __next__(self) -> 'ConfigEntry':
        return self._next_entry()

    def _next_entry(self) -> 'ConfigEntry':
        centry = ffi.new('git_config_entry **')
        err = C.git_config_next(centry, self._iter)
        check_error(err)

        return ConfigEntry._from_c(centry[0], self)


class ConfigMultivarIterator(ConfigIterator):
    def __next__(self) -> str | None:  # type: ignore[override]
        entry = self._next_entry()
        return entry.value


class Config:
    """Git configuration management.

    This class is for the reading and writing of Git configuration files.
    Configuration files are read individually, either by passing a path into
    the constructor or by using one of the static methods
    :meth:`Config.get_system_config`, :meth:`Config.get_global_config`, or
    :meth:`Config.get_xdg_config`. Additional files can be loaded into the
    `Config` object using :meth:`Config.add_file`.

    Changes made to the configuration with :meth:`Config.set_multivar` are
    immediately persisted to disk. Reads performed with accessor methods like
    :meth:`Config.get_multivar` or :meth:`Config.__getitem__` may result in
    reading from different versions of the configuration file if this or
    another process has modified the file. To avoid this and have all read
    operations occur against the same version of the configuration file, use
    :meth:`Config.snapshot()` to create a snapshot of the current config. This
    is especially important when iterating, as the contents of the config
    might change mid-iteration if you don't use a snapshot.

    This class can technically be used to manually read and write a repository's
    configuration file by pointing the constructor to the repository's
    ``.git/config`` file, but this is not recommended. The resulting ``Config``
    object represents only the configuration directly within ``.git/config``.
    It does not represent the total effective configuration for that repository
    that includes the combined system, global (user), and global (user) XDG.
    Instead, use :meth:`BaseRepository.config` for loading a repository's
    configuration.
    """

    _repo: Optional['BaseRepository']
    _config: 'GitConfigC'

    def __init__(self, path: PathLike | str | None = None) -> None:
        cconfig = ffi.new('git_config **')

        if not path:
            err = C.git_config_new(cconfig)
        else:
            path_bytes = encode_fs_path(path)
            err = C.git_config_open_ondisk(cconfig, path_bytes)

        check_error(err, io=True)
        self._repo = None
        self._config = cconfig[0]

    @classmethod
    def from_c(cls, repo: Optional['BaseRepository'], ptr: 'GitConfigC') -> 'Config':
        config = cls.__new__(cls)
        config._repo = repo
        config._config = ptr

        return config

    def __del__(self) -> None:
        try:
            C.git_config_free(self._config)
        except AttributeError:
            pass

    def _get(self, key: str | bytes) -> tuple[int, 'ConfigEntry']:
        key = str_to_bytes(key, 'key')

        entry = ffi.new('git_config_entry **')
        err = C.git_config_get_entry(entry, self._config, key)

        return err, ConfigEntry._from_c(entry[0])

    def _get_entry(self, key: str | bytes) -> 'ConfigEntry':
        err, entry = self._get(key)

        if err == C.GIT_ENOTFOUND:
            raise KeyError(key)

        check_error(err)
        return entry

    def __contains__(self, key: str | bytes) -> bool:
        err, cstr = self._get(key)

        if err == C.GIT_ENOTFOUND:
            return False

        check_error(err)

        return True

    def __getitem__(self, key: str | bytes) -> str | None:
        """
        When using the mapping interface, the value is returned as a string. In
        order to apply the git-config parsing rules, you can use
        :meth:`Config.get_bool` or :meth:`Config.get_int`.
        """
        entry = self._get_entry(key)

        return entry.value

    def __setitem__(self, key: str | bytes, value: bool | int | str | bytes) -> None:
        key = str_to_bytes(key, 'key')

        err = 0
        if isinstance(value, bool):
            err = C.git_config_set_bool(self._config, key, value)
        elif isinstance(value, int):
            err = C.git_config_set_int64(self._config, key, value)
        else:
            err = C.git_config_set_string(self._config, key, encode_string(value))

        check_error(err)

    def __delitem__(self, key: str | bytes) -> None:
        key = str_to_bytes(key, 'key')

        err = C.git_config_delete_entry(self._config, key)
        check_error(err)

    def __iter__(self) -> Iterator['ConfigEntry']:
        """
        Iterate over configuration entries, returning a ``ConfigEntry``
        objects. These contain the name, level, and value of each configuration
        variable. Be aware that this may return multiple versions of each entry
        if they are set multiple times in the configuration files.
        """
        citer = ffi.new('git_config_iterator **')
        err = C.git_config_iterator_new(citer, self._config)
        check_error(err)

        return ConfigIterator(self, citer[0])

    def get_multivar(
        self, name: str | bytes, regex: str | None = None
    ) -> ConfigMultivarIterator:
        """Get each value of a multivar ''name'' as a list of strings.

        The optional ''regex'' parameter is expected to be a regular expression
        to filter the variables we're interested in.
        """
        name = str_to_bytes(name, 'name')
        regex_bytes = encode_string(regex or None)

        citer = ffi.new('git_config_iterator **')
        err = C.git_config_multivar_iterator_new(citer, self._config, name, regex_bytes)
        check_error(err)

        return ConfigMultivarIterator(self, citer[0])

    def set_multivar(
        self, name: str | bytes, regex: str | bytes, value: str | bytes
    ) -> None:
        """Set a multivar ''name'' to ''value''. ''regexp'' is a regular
        expression to indicate which values to replace. Changes are persisted
        to the configuration file(s) backing this ``Config``.
        """
        name = str_to_bytes(name, 'name')
        regex = str_to_bytes(regex, 'regex')
        value = str_to_bytes(value, 'value')

        err = C.git_config_set_multivar(self._config, name, regex, value)
        check_error(err)

    def delete_multivar(self, name: str | bytes, regex: str | bytes) -> None:
        """Delete a multivar ''name''. ''regexp'' is a regular expression to
        indicate which values to delete. Changes are persisted to the
        configuration file(s) backing this ``Config``.
        """
        name = str_to_bytes(name, 'name')
        regex = str_to_bytes(regex, 'regex')

        err = C.git_config_delete_multivar(self._config, name, regex)
        check_error(err)

    def get_bool(self, key: str | bytes) -> bool:
        """Look up *key* and parse its value as a boolean as per the git-config
        rules. Return a boolean value (True or False).

        Truthy values are: 'true', 1, 'on' or 'yes'. Falsy values are: 'false',
        0, 'off' and 'no'
        """

        entry = self._get_entry(key)
        res = ffi.new('int *')
        err = C.git_config_parse_bool(res, entry.c_value)
        check_error(err)

        return res[0] != 0

    def get_int(self, key: bytes | str) -> int:
        """Look up *key* and parse its value as an integer as per the git-config
        rules. Return an integer.

        A value can have a suffix 'k', 'm' or 'g' which stand for 'kilo',
        'mega' and 'giga' respectively.
        """

        entry = self._get_entry(key)
        res = ffi.new('int64_t *')
        err = C.git_config_parse_int64(res, entry.c_value)
        check_error(err)

        return res[0]

    def add_file(self, path: str | PathLike, level: int = 0, force: int = 0) -> None:
        """Add a config file instance to an existing config."""

        err = C.git_config_add_file_ondisk(
            self._config, encode_fs_path(path), level, ffi.NULL, force
        )
        check_error(err)

    def snapshot(self) -> 'Config':
        """Create a snapshot from this ``Config`` object.

        This means that looking up multiple values will use the same version
        of the configuration files.
        """
        ccfg = ffi.new('git_config **')
        err = C.git_config_snapshot(ccfg, self._config)
        check_error(err)

        return Config.from_c(self._repo, ccfg[0])

    #
    # Methods to parse a string according to the git-config rules
    #

    @staticmethod
    def parse_bool(text: str) -> bool:
        res = ffi.new('int *')
        err = C.git_config_parse_bool(res, encode_string(text))
        check_error(err)

        return res[0] != 0

    @staticmethod
    def parse_int(text: str) -> int:
        res = ffi.new('int64_t *')
        err = C.git_config_parse_int64(res, encode_string(text))
        check_error(err)

        return res[0]

    #
    # Static methods to get specialized version of the config
    #

    @staticmethod
    def _from_found_config(fn: Callable) -> 'Config':
        buf = ffi.new('git_buf *', (ffi.NULL, 0))
        err = fn(buf)
        check_error(err, io=True)
        cpath = ffi.string(buf.ptr).decode('utf-8')
        C.git_buf_dispose(buf)

        return Config(cpath)

    @staticmethod
    def get_system_config() -> 'Config':
        """Return a ``Config`` object representing the system configuration file.

        The system configuration file is the one found at ``/etc/gitconfig`` or
        ``%PROGRAMFILES%\\Git\\etc\\gitconfig``, depending on the operating system.
        """
        return Config._from_found_config(C.git_config_find_system)

    @staticmethod
    def get_global_config() -> 'Config':
        """Return a ``Config`` object representing the global configuration file.

        The global configuration file is the one found at the standard user config
        location for Git, which is ``$HOME/.gitconfig``. This will not find the file
        at the XDG-compatible user config file location (for that, see
        :meth:`Config.get_xdg_config`).
        """
        return Config._from_found_config(C.git_config_find_global)

    @staticmethod
    def get_xdg_config() -> 'Config':
        """Return a ``Config`` object representing the XDG-compatible global configuration file.

        The XDG-compatible user config file follows the XDG Base Directory Specification.
        This file is located at ``$HOME/.config/git/config``. This will not find the file
        at the standard user config location (for that, see :meth:`Config.get_global_config`).
        """
        return Config._from_found_config(C.git_config_find_xdg)


class ConfigEntry:
    """An entry in a configuration object."""

    _entry: 'GitConfigEntryC'
    iterator: ConfigIterator | None

    @classmethod
    def _from_c(
        cls, ptr: 'GitConfigEntryC', iterator: ConfigIterator | None = None
    ) -> 'ConfigEntry':
        """Builds the entry from a ``git_config_entry`` pointer.

        ``iterator`` must be a ``ConfigIterator`` instance if the entry was
        created during ``git_config_iterator`` actions.
        """
        entry = cls.__new__(cls)
        entry._entry = ptr
        entry.iterator = iterator

        # It should be enough to keep a reference to iterator, so we only call
        # git_config_iterator_free when we've deleted all ConfigEntry objects.
        # But it's not, to reproduce the error comment the lines below and run
        # the script in https://github.com/libgit2/pygit2/issues/970
        # So instead we load the Python object immediately. Ideally we should
        # investigate libgit2 source code.
        if iterator is not None:
            entry.raw_name = entry.raw_name
            entry.raw_value = entry.raw_value
            entry.level = entry.level

        return entry

    def __del__(self) -> None:
        if self.iterator is None:
            C.git_config_entry_free(self._entry)

    @property
    def c_value(self) -> 'ffi.char_pointer':
        """The raw ``cData`` entry value."""
        return self._entry.value

    @cached_property
    def raw_name(self) -> bytes:
        return ffi.string(self._entry.name)

    @cached_property
    def raw_value(self) -> bytes | None:
        return ffi.string(self.c_value) if self.c_value != ffi.NULL else None

    @cached_property
    def level(self) -> int:
        """The entry's ``git_config_level_t`` value."""
        return self._entry.level

    @property
    def name(self) -> str:
        """The entry's name."""
        return self.raw_name.decode('utf-8')

    @property
    def value(self) -> str | None:
        """The entry's value as a string."""
        return self.raw_value.decode('utf-8') if self.raw_value is not None else None
