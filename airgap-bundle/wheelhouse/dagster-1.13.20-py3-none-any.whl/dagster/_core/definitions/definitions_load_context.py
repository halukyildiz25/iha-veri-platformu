import tempfile
from abc import ABC, abstractmethod
from collections.abc import Iterator, Mapping, Sequence
from contextlib import contextmanager
from enum import Enum
from functools import cached_property
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar, Generic, Optional, TypeVar, cast

from dagster_shared.serdes.objects.models.defs_state_info import (
    CODE_SERVER_STATE_VERSION,
    LOCAL_STATE_VERSION,
    DefsKeyStateInfo,
    DefsStateInfo,
    DefsStateManagementType,
)
from dagster_shared.serdes.serdes import PackableValue, deserialize_value, serialize_value

from dagster._core.definitions.assets.definition.cacheable_assets_definition import (
    AssetsDefinitionCacheableData,
)
from dagster._core.definitions.definitions_class import Definitions
from dagster._core.definitions.metadata.metadata_value import (
    CodeLocationReconstructionMetadataValue,
)
from dagster._core.errors import DagsterInvalidInvocationError, DagsterInvariantViolationError
from dagster._core.storage.defs_state.base import DefsStateStorage
from dagster.components.utils.defs_state import DefsStateConfig
from dagster.components.utils.project_paths import (
    get_code_server_metadata_key,
    get_local_state_path,
)

if TYPE_CHECKING:
    from dagster._core.definitions.repository_definition import RepositoryLoadData


class DefinitionsLoadType(Enum):
    """An enum that defines the different scenarios in which a Definitions object may be
    instantiated.

    When booting a Dagster process that contains definitions, one of two things are happening.

    1. `INITIALIZATION`: You are defining a set of definitions for Dagster to ingest, effectively updating Dagster's
        understanding of the world at a point in time.
    2. `RECONSTRUCTION`: You are reconstructing a set of definitions that were previously defined.

    This distinction is important when the source of truth for a Dagster definition is state
    (for example in a hosted ingestion or BI tool accessable via an API). The state should
    only be accessed when defining definitions, whereas when reconstructing definitions that
    state should be retrieved from Dagster's metastore.
    """

    INITIALIZATION = "INITIALIZATION"
    RECONSTRUCTION = "RECONSTRUCTION"


class DefinitionsLoadContext:
    """Holds data that's made available to Definitions-loading code when a DefinitionsLoader is
    invoked.
    User construction of this object is not supported.
    """

    _instance: ClassVar[Optional["DefinitionsLoadContext"]] = None

    def __init__(
        self,
        load_type: DefinitionsLoadType,
        repository_load_data: Optional["RepositoryLoadData"] = None,
    ):
        self._load_type = load_type
        self._repository_load_data = repository_load_data
        self._pending_reconstruction_metadata = {}

        defs_state_info = repository_load_data.defs_state_info if repository_load_data else None

        # keep track of the keys that have been accessed during the load process
        self._accessed_defs_state_keys = (
            set() if defs_state_info is None else set(defs_state_info.info_mapping.keys())
        )
        if load_type == DefinitionsLoadType.INITIALIZATION and defs_state_info is None:
            # defs_state_info is passed in during INITIALIZATION if explicit state versions
            # are provided via CLI arguments, otherwise we use the latest available state info
            state_storage = DefsStateStorage.get()
            self._defs_state_info = (
                state_storage.get_latest_defs_state_info() if state_storage else None
            )
        else:
            self._defs_state_info = defs_state_info

    @classmethod
    def get(cls) -> "DefinitionsLoadContext":
        """Get the current DefinitionsLoadContext. If it has not been set, the
        context is assumed to be in initialization, and the state versions are
        set to the latest available versions.
        """
        return DefinitionsLoadContext._instance or cls(load_type=DefinitionsLoadType.INITIALIZATION)

    @classmethod
    def set(cls, instance: "DefinitionsLoadContext") -> None:
        """Get the current DefinitionsLoadContext."""
        cls._instance = instance

    @classmethod
    def is_set(cls) -> bool:
        """bool: Whether the context has been set."""
        return cls._instance is not None

    @classmethod
    @contextmanager
    def scoped(cls, instance: "DefinitionsLoadContext") -> Iterator["DefinitionsLoadContext"]:
        """Install ``instance`` as the singleton for the duration of the block, then
        restore whatever was previously set (which may be unset).

        Distinct from ``set``: this snapshots the underlying value — including
        the "unset" state — so an outer scope that hadn't installed a context
        isn't left pinned to a fresh INITIALIZATION context after the block exits.
        """
        prev = cls._instance
        cls._instance = instance
        try:
            yield instance
        finally:
            cls._instance = prev

    @property
    def load_type(self) -> DefinitionsLoadType:
        """DefinitionsLoadType: Classifier for scenario in which Definitions are being loaded."""
        return self._load_type

    @property
    def code_location_name(self) -> str | None:
        """The name of the code location being loaded, as reported by the loading harness
        (gRPC server / workspace). This is the authoritative name of the location -- the one
        the rest of the system (including app-managed component state keys) refers to it by.
        None when loading outside a workspace context (e.g. direct CLI invocations), in which
        case callers may fall back to a project-config-derived name.
        """
        return self._repository_load_data.code_location_name if self._repository_load_data else None

    def add_to_pending_reconstruction_metadata(self, key: str, metadata: Any) -> None:
        self._pending_reconstruction_metadata[key] = metadata

    def add_code_server_defs_state_info(self, key: str, metadata: Any) -> None:
        """Marks state that was stored during the code server initialization process."""
        self._defs_state_info = DefsStateInfo.add_version(
            self._defs_state_info, key, CODE_SERVER_STATE_VERSION
        )
        self.add_to_pending_reconstruction_metadata(get_code_server_metadata_key(key), metadata)

    def get_pending_reconstruction_metadata(self) -> Mapping[str, Any]:
        return self._pending_reconstruction_metadata

    @property
    def cacheable_asset_data(self) -> Mapping[str, Sequence[AssetsDefinitionCacheableData]]:
        """Sequence[AssetDefinitionCacheableData]: A sequence of cacheable asset data created
        during code location initialization. Accessing this during initialization will raise an
        error.
        """
        if self._load_type == DefinitionsLoadType.INITIALIZATION:
            raise DagsterInvariantViolationError(
                "Attempted to access cacheable asset data during code location initialization."
                " Cacheable asset data is only available during reconstruction of a code location."
            )
        return self._repository_load_data.cacheable_asset_data if self._repository_load_data else {}

    @cached_property
    def reconstruction_metadata(self) -> Mapping[str, Any]:
        """Mapping[str, Any]: A dictionary containing metadata from the returned Definitions object
        at initial code location initialization. Accessing this during initialization will raise an
        error.
        """
        if self._load_type == DefinitionsLoadType.INITIALIZATION:
            raise DagsterInvariantViolationError(
                "Attempted to access code location metadata during code location initialization."
                " Code location metadata is only available during reconstruction of a code location."
            )
        # Expose the wrapped metadata values so that users access exactly what they put in.
        return (
            {
                k: v.data if isinstance(v, CodeLocationReconstructionMetadataValue) else v
                for k, v in self._repository_load_data.reconstruction_metadata.items()
            }
            if self._repository_load_data
            else {}
        )

    @property
    def accessed_defs_state_info(self) -> DefsStateInfo | None:
        return (
            self._defs_state_info.for_keys(self._accessed_defs_state_keys)
            if self._defs_state_info
            else None
        )

    def _mark_defs_key_accessed(self, key: str) -> None:
        self._accessed_defs_state_keys.add(key)

    def get_defs_key_state_info(self, key: str) -> DefsKeyStateInfo | None:
        """Returns the pinned state info for the given defs key, or None if no
        version is pinned. Marks the key as accessed so it shows up in
        ``accessed_defs_state_info``.
        """
        self._mark_defs_key_accessed(key)
        current_info = self._defs_state_info or DefsStateInfo.empty()
        key_info = current_info.info_mapping.get(key)
        if key_info is None:
            self._defs_state_info = DefsStateInfo.add_version(current_info, key, None)
        return key_info

    def state_keys_with_prefix(self, prefix: str) -> list[str]:
        """Returns the pinned defs state keys that start with ``prefix``.

        Read-only — does not mark keys as accessed. Mirrors
        ``DefsStateStorage.list_state_keys_with_prefix`` but reads from the
        snapshot pinned on this load context, which is what callers want when
        they need a listing that's consistent with the versions being loaded
        against (e.g. during ``RECONSTRUCTION`` or a ``ReloadCodeWithState``
        flow that pins an explicit ``DefsStateInfo``).
        """
        if self._defs_state_info is None:
            return []
        return sorted(
            k
            for k, v in self._defs_state_info.info_mapping.items()
            if v is not None and k.startswith(prefix)
        )

    def _get_defs_state_from_reconstruction_metadata(self, key: str) -> str:
        metadata_key = get_code_server_metadata_key(key)
        if self.load_type == DefinitionsLoadType.RECONSTRUCTION:
            return self.reconstruction_metadata[metadata_key]
        else:
            return self._pending_reconstruction_metadata[metadata_key]

    def add_defs_state_info(
        self, key: str, version: str, create_timestamp: float | None = None
    ) -> None:
        self._mark_defs_key_accessed(key)
        self._defs_state_info = DefsStateInfo.add_version(
            self._defs_state_info, key, version, create_timestamp
        )

    @contextmanager
    def state_path(
        self, config: DefsStateConfig, state_storage: DefsStateStorage | None, project_root: Path
    ) -> Iterator[Path | None]:
        """Context manager that creates a temporary path to hold local state for a component.

        Args:
            config: The state configuration for the component.
            state_storage: The state storage instance.
            project_root: The root directory of the project.
        """
        # if no state has ever been written for this key, we return None to indicate that no state is available
        key = config.key
        key_info = self.get_defs_key_state_info(key)

        if config.management_type == DefsStateManagementType.LOCAL_FILESYSTEM:
            # it is possible for local state to exist without the defs_state_storage being aware
            # of it if the state was added during docker build
            state_path = get_local_state_path(key, project_root)
            if not state_path.exists():
                yield None
                return
            self.add_defs_state_info(key, LOCAL_STATE_VERSION, state_path.stat().st_ctime)
            yield state_path
        elif config.management_type == DefsStateManagementType.VERSIONED_STATE_STORAGE:
            if state_storage is None:
                raise DagsterInvalidInvocationError(
                    f"Attempted to access state for key {config.key} with management type {config.management_type} "
                    "without a StateStorage in context. This is likely the result of an internal framework error."
                )
            key_info = self.get_defs_key_state_info(key)
            # this implies that no state has been stored since the management type was changed
            if key_info is None or key_info.management_type != config.management_type:
                yield None
                return
            # grab state for storage
            with tempfile.TemporaryDirectory() as temp_dir:
                state_path = Path(temp_dir) / "state"
                state_storage.download_state_to_path(key, key_info.version, state_path)
                yield state_path
        elif config.management_type == DefsStateManagementType.LEGACY_CODE_SERVER_SNAPSHOTS:
            # state is stored in the reconstruction metadata
            with tempfile.TemporaryDirectory() as temp_dir:
                state_path = Path(temp_dir) / "state"
                state = self._get_defs_state_from_reconstruction_metadata(key)
                state_path.write_text(state)
                yield state_path
        else:
            raise DagsterInvariantViolationError(
                f"Invalid management type: {config.management_type}"
            )


TState = TypeVar("TState", bound=PackableValue)


class StateBackedDefinitionsLoader(ABC, Generic[TState]):
    """A class for building state-backed definitions. In a structured way. It
    handles manipulation of the DefinitionsLoadContext on the user's behalf.

    The goal here is so that an unreliable backing source is fetched only
    at code server load time, which defines the code location. When, for example,
    a run worker is launched, the backing source is not queryed again, and
    only `defs_from_state` is called.

    Current meant for internal usage only hence TState must be a marked as whitelist_for_serdes.

    Args:
        defs_key (str): The unique key for the definitions. Must be unique per code location.

    Examples:

    .. code-block:: python

        @whitelist_for_serdes
        @record
        class ExampleDefState:
            a_string: str

        class ExampleStateBackedDefinitionsLoader(StateBackedDefinitionsLoader[ExampleDefState]):
            def fetch_state(self) -> ExampleDefState:
                # Fetch from potentially unreliable API (e.g. Rest API)
                return ExampleDefState(a_string="foo")

            def defs_from_state(self, state: ExampleDefState) -> Definitions:
                # Construct or reconstruct the Definitions from the previously
                # fetched state.
                return Definitions([AssetSpec(key=state.a_string)])
    """

    @property
    @abstractmethod
    def defs_key(self) -> str:
        """The unique key for the definitions. Must be unique per code location."""
        ...

    @abstractmethod
    def fetch_state(self) -> TState:
        """Subclasses must implement this method. This is where the integration runs
        code that fetches the backing state from the source of truth for the definitions.
        This is only called when the code location is initializing, for example on
        code server load, or when loading via dagster dev.
        """
        ...

    @abstractmethod
    def defs_from_state(self, state: TState) -> Definitions:
        """Subclasses must implement this method. It is invoked whenever the code location
        is loading, whether it be initializaton or reconstruction. In the case of
        intialization, it takes the result of fetch_backing state that just happened.
        When reconstructing, it takes the state that was previously fetched and attached
        as metadata.

        This method also takes responsibility for attaching the state to the definitions
        on its metadata, with the key passed in as defs_key.
        """
        ...

    def get_or_fetch_state(self) -> TState:
        context = DefinitionsLoadContext.get()
        state = (
            cast("TState", deserialize_value(context.reconstruction_metadata[self.defs_key]))
            if (
                context.load_type == DefinitionsLoadType.RECONSTRUCTION
                and self.defs_key in context.reconstruction_metadata
            )
            else self.fetch_state()
        )
        context.add_to_pending_reconstruction_metadata(self.defs_key, serialize_value(state))

        return state

    def build_defs(self) -> Definitions:
        state = self.get_or_fetch_state()

        return self.defs_from_state(state).with_reconstruction_metadata(
            {self.defs_key: serialize_value(state)}
        )
