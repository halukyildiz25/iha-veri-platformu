import keyword
import os
import re
from collections.abc import (
    Iterable,
    Mapping,
    Sequence,
    Set as AbstractSet,
)
from glob import glob
from typing import TYPE_CHECKING, Annotated, Any, Optional, TypeVar, Union, cast

import yaml
from dagster_shared.yaml_utils import merge_yaml_strings, merge_yamls

import dagster._check as check
from dagster._core.definitions.asset_key import AssetCheckKey, AssetJobKey, EntityKey
from dagster._core.errors import DagsterInvalidDefinitionError, DagsterInvariantViolationError
from dagster._core.utils import is_valid_email
from dagster._record import ImportFrom, record
from dagster._utils.warnings import deprecation_warning, disable_dagster_warnings

DEFAULT_OUTPUT = "result"
DEFAULT_GROUP_NAME = "default"  # asset group_name used when none is provided
DEFAULT_IO_MANAGER_KEY = "io_manager"

DISALLOWED_NAMES = set(
    [
        "context",
        "conf",
        "config",
        "meta",
        "arg_dict",
        "dict",
        "input_arg_dict",
        "output_arg_dict",
        "int",
        "str",
        "float",
        "bool",
        "input",
        "output",
        "type",
    ]
    + list(keyword.kwlist)  # just disallow all python keywords
)

INVALID_NAME_CHARS = r"[^A-Za-z0-9_]"
VALID_NAME_REGEX_STR = r"^[A-Za-z0-9_]+$"
VALID_NAME_REGEX = re.compile(VALID_NAME_REGEX_STR)

# Group names allow `/` separators between segments, where each segment must
# match VALID_NAME_REGEX. Derived from VALID_NAME_REGEX_STR so the two stay in
# sync.
_VALID_NAME_SEGMENT = VALID_NAME_REGEX_STR.strip("^$")
VALID_GROUP_NAME_REGEX = re.compile(rf"^{_VALID_NAME_SEGMENT}(/{_VALID_NAME_SEGMENT})*$")

INVALID_TITLE_CHARACTERS_REGEX_STR = r"[\%\*\"]"
INVALID_TITLE_CHARACTERS_REGEX = re.compile(INVALID_TITLE_CHARACTERS_REGEX_STR)
MAX_TITLE_LENGTH = 100

if TYPE_CHECKING:
    from dagster._core.definitions.asset_key import AssetKey
    from dagster._core.definitions.asset_selection import AssetSelection
    from dagster._core.definitions.assets.graph.base_asset_graph import BaseAssetGraph
    from dagster._core.definitions.auto_materialize_policy import AutoMaterializePolicy
    from dagster._core.definitions.declarative_automation.automation_condition import (
        AutomationCondition,
    )
    from dagster._core.definitions.sensor_definition import SensorDefinition
    from dagster._core.remote_representation.external import RemoteSensor


class NoValueSentinel:
    """Sentinel value to distinguish unset from None."""


def has_valid_name_chars(name: str) -> bool:
    return bool(VALID_NAME_REGEX.match(name))


def check_valid_name(name: str, allow_list: list[str] | None = None) -> str:
    check.str_param(name, "name")

    if allow_list and name in allow_list:
        return name

    if name in DISALLOWED_NAMES:
        raise DagsterInvalidDefinitionError(
            f'"{name}" is not a valid name in Dagster. It conflicts with a Dagster or python'
            " reserved keyword."
        )

    check_valid_chars(name)

    check.invariant(is_valid_name(name))
    return name


def check_valid_chars(name: str):
    if not has_valid_name_chars(name):
        raise DagsterInvalidDefinitionError(
            f'"{name}" is not a valid name in Dagster. Names must be in regex'
            f" {VALID_NAME_REGEX_STR}."
        )


def is_valid_name(name: str) -> bool:
    check.str_param(name, "name")

    return name not in DISALLOWED_NAMES and has_valid_name_chars(name)


def is_valid_title_and_reason(title: str | None) -> tuple[bool, str | None]:
    check.opt_str_param(title, "title")

    if title is None:
        return True, None

    if len(title) > MAX_TITLE_LENGTH:
        return (
            False,
            f'"{title}" ({len(title)} characters) is not a valid title in Dagster. Titles must not be longer than {MAX_TITLE_LENGTH}.',
        )

    if not is_valid_title_chars(title):
        return (
            False,
            f'"{title}" is not a valid title in Dagster. Titles must not contain regex {INVALID_TITLE_CHARACTERS_REGEX_STR}.',
        )

    return True, None


def check_valid_title(title: str | None) -> str | None:
    """A title is distinguished from a name in that the title is a descriptive string meant for display in the UI.
    It is not used as an identifier for an object.
    """
    is_valid, reason = is_valid_title_and_reason(title)
    if not is_valid:
        raise DagsterInvariantViolationError(reason)

    return title


def is_valid_title(title: str | None) -> bool:
    return is_valid_title_and_reason(title)[0]


def is_valid_title_chars(title: str):
    return not bool(INVALID_TITLE_CHARACTERS_REGEX.search(title))


def _kv_str(key: object, value: object) -> str:
    return f'{key}="{value!r}"'


def struct_to_string(name: str, **kwargs: object) -> str:
    # Sort the kwargs to ensure consistent representations across Python versions
    props_str = ", ".join([_kv_str(key, value) for key, value in sorted(kwargs.items())])
    return f"{name}({props_str})"


def is_valid_owner(owner: str) -> bool:
    return is_valid_email(owner) or (owner.startswith("team:") and len(owner) > 5)


def validate_asset_owner(owner: str, key: "AssetKey") -> None:
    if not is_valid_owner(owner):
        raise DagsterInvalidDefinitionError(
            f"Invalid owner '{owner}' for asset '{key}'. Owner must be an email address or a team "
            "name prefixed with 'team:'."
        )


def validate_component_owner(owner: str) -> None:
    if not is_valid_owner(owner):
        raise DagsterInvalidDefinitionError(
            f"Invalid owner '{owner}'. Owner must be an email address or a team "
            "name prefixed with 'team:'."
        )


def validate_definition_owner(owner: str, definition_type: str, definition_name: str) -> None:
    """Owner validation for jobs, sensors, and schedules.

    Args:
        owner: The owner string to validate. Must be either a valid email address or a team name
            prefixed with 'team:'
        definition_type: Type of definition (e.g., "job", "sensor", "schedule") for error messages
        definition_name: Name of the definition for error messages

    Raises:
        DagsterInvalidDefinitionError: When owner is not a valid email or team name
    """
    if not is_valid_owner(owner):
        if owner.startswith("team:") and len(owner) <= 5:
            raise DagsterInvalidDefinitionError(
                f"Invalid owner '{owner}' for {definition_type} '{definition_name}'. "
                "Team name cannot be empty after 'team:' prefix."
            )
        else:
            raise DagsterInvalidDefinitionError(
                f"Invalid owner '{owner}' for {definition_type} '{definition_name}'. "
                "Owner must be an email address or a team name prefixed with 'team:'."
            )


def validate_group_name(group_name: str | None) -> None:
    """Ensures a string group name is valid.

    Group names may use ``/`` as a separator to express hierarchy
    (e.g. ``"marketing/foo/bar"``). Each path segment must match
    ``[A-Za-z0-9_]+``; leading, trailing, and consecutive separators
    are not permitted.
    """
    if group_name:
        if not VALID_GROUP_NAME_REGEX.match(group_name):
            raise DagsterInvalidDefinitionError(
                f'"{group_name}" is not a valid asset group name. Group names must be '
                "one or more segments matching "
                f"{VALID_NAME_REGEX_STR} separated by '/' "
                "(e.g. 'marketing' or 'marketing/foo/bar')."
            )
    elif group_name == "":
        raise DagsterInvalidDefinitionError(
            "Empty asset group name was provided, which is not permitted. "
            "Set group_name=None to use the default group_name or set non-empty string"
        )


def normalize_group_name(group_name: str | None) -> str:
    """Ensures a string name is valid and returns a default if no name provided."""
    validate_group_name(group_name)
    return group_name or DEFAULT_GROUP_NAME


def config_from_files(config_files: Sequence[str]) -> Mapping[str, Any]:
    """Constructs run config from YAML files.

    Args:
        config_files (List[str]): List of paths or glob patterns for yaml files
            to load and parse as the run config.

    Returns:
        Dict[str, Any]: A run config dictionary constructed from provided YAML files.

    Raises:
        FileNotFoundError: When a config file produces no results
        DagsterInvariantViolationError: When one of the YAML files is invalid and has a parse
            error.
    """
    config_files = check.opt_sequence_param(config_files, "config_files")

    filenames = []
    for file_glob in config_files or []:
        globbed_files = glob(file_glob)
        if not globbed_files:
            raise DagsterInvariantViolationError(
                f'File or glob pattern "{file_glob}" for "config_files" produced no results.'
            )

        filenames += [os.path.realpath(globbed_file) for globbed_file in globbed_files]

    try:
        run_config = merge_yamls(filenames)
    except yaml.YAMLError as err:
        raise DagsterInvariantViolationError(
            f"Encountered error attempting to parse yaml. Parsing files {filenames} "
            f"loaded by file/patterns {config_files}."
        ) from err

    return check.is_dict(cast("dict[str, object]", run_config), key_type=str)


def config_from_yaml_strings(yaml_strings: Sequence[str]) -> Mapping[str, Any]:
    """Static constructor for run configs from YAML strings.

    Args:
        yaml_strings (List[str]): List of yaml strings to parse as the run config.

    Returns:
        Dict[Str, Any]: A run config dictionary constructed from the provided yaml strings

    Raises:
        DagsterInvariantViolationError: When one of the YAML documents is invalid and has a
            parse error.
    """
    yaml_strings = check.sequence_param(yaml_strings, "yaml_strings", of_type=str)

    try:
        run_config = merge_yaml_strings(yaml_strings)
    except yaml.YAMLError as err:
        raise DagsterInvariantViolationError(
            f"Encountered error attempting to parse yaml. Parsing YAMLs {yaml_strings} "
        ) from err

    return check.is_dict(cast("dict[str, object]", run_config), key_type=str)


def config_from_pkg_resources(pkg_resource_defs: Sequence[tuple[str, str]]) -> Mapping[str, Any]:
    """Load a run config from a package resource, using :py:func:`pkg_resources.resource_string`.

    Example:
        .. code-block:: python

            config_from_pkg_resources(
                pkg_resource_defs=[
                    ('dagster_examples.airline_demo.environments', 'local_base.yaml'),
                    ('dagster_examples.airline_demo.environments', 'local_warehouse.yaml'),
                ],
            )


    Args:
        pkg_resource_defs (List[(str, str)]): List of pkg_resource modules/files to
            load as the run config.

    Returns:
        Dict[Str, Any]: A run config dictionary constructed from the provided yaml strings

    Raises:
        DagsterInvariantViolationError: When one of the YAML documents is invalid and has a
            parse error.
    """
    import importlib.resources

    pkg_resource_defs = check.sequence_param(pkg_resource_defs, "pkg_resource_defs", of_type=tuple)

    try:
        yaml_strings = [
            importlib.resources.files(pkg_name).joinpath(filename).read_text()
            for pkg_name, filename in pkg_resource_defs
        ]
    except (ModuleNotFoundError, FileNotFoundError, UnicodeDecodeError) as err:
        raise DagsterInvariantViolationError(
            "Encountered error attempting to parse yaml. Loading YAMLs from "
            f"package resources {pkg_resource_defs}."
        ) from err

    return config_from_yaml_strings(yaml_strings=yaml_strings)


def resolve_automation_condition(
    automation_condition: Optional["AutomationCondition"],
    auto_materialize_policy: Optional["AutoMaterializePolicy"],
) -> Optional["AutomationCondition"]:
    if auto_materialize_policy is not None:
        deprecation_warning(
            "Parameter `auto_materialize_policy`",
            "1.9",
            additional_warn_text="Use `automation_condition` instead.",
        )
        if automation_condition is not None:
            raise DagsterInvariantViolationError(
                "Cannot supply both `automation_condition` and `auto_materialize_policy`"
            )
        return auto_materialize_policy.to_automation_condition()
    else:
        return automation_condition


T = TypeVar("T")


def dedupe_object_refs(objects: Iterable[T] | None) -> Sequence[T]:
    """Dedupe definitions by reference equality."""
    return list({id(obj): obj for obj in objects}.values()) if objects is not None else []


@record
class DefaultAutomationSensorTarget:
    """What the default automation condition sensor should cover: a lazy asset
    selection (possibly empty, for a sensor that only hosts jobs), plus the
    conditioned asset-job keys not claimed by any user sensor.

    The two halves are intentionally asymmetric: asset coverage is an expression that
    re-resolves as the asset graph changes, while job coverage has no selection
    language yet and is expressed as explicit keys (see the TODO below on replacing
    this with a first-class job-selection API).
    """

    asset_selection: Annotated[
        "AssetSelection", ImportFrom("dagster._core.definitions.asset_selection")
    ]
    asset_job_keys: AbstractSet[AssetJobKey]


def get_default_automation_condition_sensor(
    sensors: Sequence["SensorDefinition"],
    asset_graph: "BaseAssetGraph",
    additional_automatable_asset_job_keys: AbstractSet["AssetJobKey"] | None = None,
) -> Optional["SensorDefinition"]:
    """Given a list of existing sensors, adds an AutomationConditionSensorDefinition with name
    `default_automation_condition_sensor` that targets all assets/asset_checks that have an
    automation_condition and are not targeted by an existing AutomationConditionSensorDefinition
    if any such untargeted assets/asset_checks exist.
    """
    from dagster._core.definitions.automation_condition_sensor_definition import (
        DEFAULT_AUTOMATION_CONDITION_SENSOR_NAME,
        AutomationConditionSensorDefinition,
    )

    with disable_dagster_warnings():
        target = get_default_automation_condition_sensor_target(
            sensors,
            asset_graph,
            additional_automatable_asset_job_keys=additional_automatable_asset_job_keys,
        )
        if target:
            return AutomationConditionSensorDefinition(
                DEFAULT_AUTOMATION_CONDITION_SENSOR_NAME,
                target=target.asset_selection,
                asset_job_keys=target.asset_job_keys,
            )

    return None


def get_default_automation_condition_sensor_target(
    sensors: Sequence[Union["SensorDefinition", "RemoteSensor"]],
    asset_graph: "BaseAssetGraph",
    additional_automatable_asset_job_keys: AbstractSet["AssetJobKey"] | None = None,
) -> DefaultAutomationSensorTarget | None:
    from dagster._core.definitions.asset_selection import AssetSelection
    from dagster._core.definitions.automation_condition_sensor_definition import (
        asset_job_keys_from_sensor_metadata,
    )
    from dagster._core.definitions.sensor_definition import SensorType

    automation_condition_sensors = sorted(
        (
            s
            for s in sensors
            if s.sensor_type in (SensorType.AUTO_MATERIALIZE, SensorType.AUTOMATION)
        ),
        key=lambda s: s.name,
    )

    automation_condition_keys = set()
    for k in asset_graph.materializable_asset_keys | asset_graph.asset_check_keys:
        if asset_graph.get(k).automation_condition is not None:
            automation_condition_keys.add(k)

    has_auto_observe_keys = False
    for k in asset_graph.observable_asset_keys:
        if (
            # for backcompat, treat auto-observe assets as if they have a condition
            asset_graph.get(k).automation_condition is not None
            or asset_graph.get(k).auto_observe_interval_minutes is not None
        ):
            has_auto_observe_keys = True
            automation_condition_keys.add(k)

    # get the set of keys that are handled by an existing sensor. sensor asset
    # selections cannot express job keys, so a conditioned job is never covered by an
    # explicit sensor and always lands on the default sensor
    # get the set of keys that are handled by an existing sensor
    covered_keys: set[EntityKey] = set()
    for sensor in automation_condition_sensors:
        selection = check.not_none(sensor.asset_selection)
        covered_keys = covered_keys.union(
            selection.resolve(asset_graph) | selection.resolve_checks(asset_graph)
        )

    # Asset selections cannot express job keys, so job keys are handled separately: a
    # sensor claims job keys via its (hidden) asset_job_keys parameter, carried in
    # sensor metadata, and the default sensor claims every conditioned job key not
    # claimed by an existing sensor. Only job keys explicitly passed in by the caller
    # (repository_data_builder) are considered; do NOT pull from
    # asset_graph.automatable_asset_job_keys here — the host-side
    # RemoteRepository._sensors also calls this function, and including job keys there
    # would cause the default sensor to be re-created with an empty selection.
    # TODO: create a new first-class field on the sensor for asset jobs. Deferring this
    # for now in the interest of stabilizing the implementation before worrying about
    # the longer term API.
    covered_job_keys: set[AssetJobKey] = set()
    for sensor in automation_condition_sensors:
        covered_job_keys |= asset_job_keys_from_sensor_metadata(sensor.metadata)
    uncovered_job_keys = (additional_automatable_asset_job_keys or set()) - covered_job_keys

    default_sensor_keys = automation_condition_keys - covered_keys
    if len(default_sensor_keys) > 0:
        # Use AssetSelection.all if the default sensor is the only sensor - otherwise
        # enumerate the assets that are not already included in some other
        # non-default sensor
        default_sensor_asset_selection = AssetSelection.all(include_sources=has_auto_observe_keys)

        # if there are any asset checks, include checks in the selection
        if any(isinstance(k, AssetCheckKey) for k in default_sensor_keys):
            default_sensor_asset_selection |= AssetSelection.all_asset_checks()

        # remove any selections that are already covered
        for sensor in automation_condition_sensors:
            default_sensor_asset_selection = default_sensor_asset_selection - check.not_none(
                sensor.asset_selection
            )
        return DefaultAutomationSensorTarget(
            asset_selection=default_sensor_asset_selection, asset_job_keys=uncovered_job_keys
        )
    elif uncovered_job_keys:
        # No uncovered assets/checks, but a default sensor is still needed to host the
        # uncovered job keys, with an empty asset selection
        return DefaultAutomationSensorTarget(
            asset_selection=AssetSelection.keys(), asset_job_keys=uncovered_job_keys
        )
    # no additional sensor required
    else:
        return None
